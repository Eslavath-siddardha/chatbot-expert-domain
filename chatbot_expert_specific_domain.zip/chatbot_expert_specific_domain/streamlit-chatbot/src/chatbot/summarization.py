from transformers import pipeline

def summarize_paper(paper_text):
    summarizer = pipeline("summarization")
    summary = summarizer(paper_text, max_length=150, min_length=30, do_sample=False)
    return summary[0]['summary_text']