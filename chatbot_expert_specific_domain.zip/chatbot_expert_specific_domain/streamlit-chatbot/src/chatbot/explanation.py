from transformers import pipeline

def generate_explanation(concept: str) -> str:
    """
    Generate an explanation for a given concept using a language model.

    Parameters:
    concept (str): The concept to explain.

    Returns:
    str: A detailed explanation of the concept.
    """
    # Load a pre-trained language model for explanation generation
    explanation_model = pipeline("text-generation", model="gpt-2")
    
    # Generate explanation
    prompt = f"Explain the concept of {concept} in simple terms."
    explanation = explanation_model(prompt, max_length=150, num_return_sequences=1)[0]['generated_text']
    
    return explanation.strip()