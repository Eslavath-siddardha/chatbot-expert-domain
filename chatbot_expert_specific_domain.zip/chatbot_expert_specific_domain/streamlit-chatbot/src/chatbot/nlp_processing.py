from nltk.tokenize import word_tokenize
from nltk import pos_tag, ne_chunk
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import spacy

class NLPProcessor:
    def __init__(self):
        self.nlp = spacy.load("en_core_web_sm")
        self.vectorizer = TfidfVectorizer()

    def tokenize(self, text):
        return word_tokenize(text)

    def pos_tagging(self, tokens):
        return pos_tag(tokens)

    def named_entity_recognition(self, text):
        doc = self.nlp(text)
        return [(ent.text, ent.label_) for ent in doc.ents]

    def compute_similarity(self, text1, text2):
        tfidf_matrix = self.vectorizer.fit_transform([text1, text2])
        return cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]

    def extract_keywords(self, text, num_keywords=5):
        doc = self.nlp(text)
        keywords = [token.text for token in doc if token.is_stop != True and token.is_punct != True]
        return keywords[:num_keywords]