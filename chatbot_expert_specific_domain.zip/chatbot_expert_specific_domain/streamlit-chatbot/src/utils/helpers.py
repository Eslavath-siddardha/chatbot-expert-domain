def format_output(text):
    """Format the output text for better readability."""
    return text.strip()

def handle_user_input(user_input):
    """Process and sanitize user input."""
    return user_input.strip()

def log_interaction(user_input, bot_response):
    """Log the interaction between user and bot for future analysis."""
    with open("interaction_log.txt", "a") as log_file:
        log_file.write(f"User: {user_input}\nBot: {bot_response}\n\n")