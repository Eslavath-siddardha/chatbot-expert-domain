import streamlit as st
from chatbot.nlp_processing import process_input
from chatbot.summarization import summarize_paper
from chatbot.explanation import generate_explanation
from data.arxiv_dataset_loader import load_arxiv_data

def main():
    st.title("ArXiv Expert Chatbot")
    st.write("Welcome to the ArXiv Expert Chatbot! Ask me anything about scientific papers.")

    user_input = st.text_input("Your question:")
    
    if st.button("Submit"):
        if user_input:
            # Process the user input
            processed_input = process_input(user_input)
            
            # Load the arXiv dataset
            arxiv_data = load_arxiv_data()
            
            # Generate a summary or explanation based on the input
            if "summarize" in processed_input:
                summary = summarize_paper(processed_input)
                st.write("Summary:", summary)
            elif "explain" in processed_input:
                explanation = generate_explanation(processed_input)
                st.write("Explanation:", explanation)
            else:
                st.write("I'm not sure how to respond to that. Please ask about summarization or explanation.")
        else:
            st.write("Please enter a question.")

if __name__ == "__main__":
    main()