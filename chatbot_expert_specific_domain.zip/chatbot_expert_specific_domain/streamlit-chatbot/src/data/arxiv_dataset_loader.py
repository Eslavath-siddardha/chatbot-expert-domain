import pandas as pd
import os

def load_arxiv_dataset(file_path: str) -> pd.DataFrame:
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"The file at {file_path} does not exist.")
    
    # Load the dataset
    dataset = pd.read_csv(file_path)
    
    # Basic preprocessing
    dataset.dropna(subset=['title', 'abstract'], inplace=True)
    
    return dataset

def filter_dataset_by_category(dataset: pd.DataFrame, category: str) -> pd.DataFrame:
    return dataset[dataset['categories'].str.contains(category, case=False, na=False)]

def get_paper_titles(dataset: pd.DataFrame) -> list:
    return dataset['title'].tolist()